#!/bin/sh
echo "Start"
while (true) 
do
 ./75.sh;
 sleep 75; 
  ./50.sh;
 sleep 98; 
   ./80.sh;
 sleep 85; 
   ./65.sh;
 sleep 78; 
   ./90.sh;
 sleep 69; 
  ./40.sh;
 sleep 99; 
done;





